-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 12, 2023 at 05:55 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `madusa_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `quantity` int NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `price`, `quantity`, `image`) VALUES
(11, 11, 'Skin Toner', 5000, 5, 'Skin Toner - Jovees.jpg'),
(12, 11, 'Body Lotion', 3000, 8, 'Body Lotions.jpg'),
(19, 10, 'Lipstick Matte', 4500, 5, 'Lipsticl Matte - Enchanteur.jpg'),
(20, 10, 'Night Cream', 8990, 3, 'Night Cream - Oriflame.jpg'),
(44, 17, 'Shampoo & Conditionor', 7000, 2, 'Shampoo _ Conditionor -Tresemme.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(2, 'Mascara'),
(13, 'Shampoo'),
(12, 'Perfume'),
(11, 'Skin Toner'),
(10, 'Lipstick'),
(14, 'Body Lotion'),
(15, 'Face Cream'),
(16, 'Night Cream'),
(21, 'Kalpana');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(10) NOT NULL,
  `message` varchar(500) NOT NULL,
  `image` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'NotApproved',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `user_id`, `name`, `email`, `number`, `message`, `image`, `status`) VALUES
(48, 24, 'Joanna', 'joanna@gmail.com', '0716666777', 'Love the smell!! Fantastic products! Great present for my other half who loved them also, will definitely be buying them again! Just fantastic! Thank you!', 'pic-6.jpg', 'Approve'),
(49, 24, 'Rosie', 'rosie@gmail.com', '0778822333', 'Amazing as always. I have been using Conscious Skincare for over a year now (my mom as well!) and all of the products are incredibly good for my skin. Highly recommended!', 'pic-7.jpg', 'Approve'),
(30, 17, 'Lily', 'lily@gmail.com', '0723335556', 'Thank you so much for creating your beautiful, natural, organic, environmentally friendly skin care products. It makes my skin look smoother and less tired!\r\n         ', 'pic-3.jpg', 'Approve'),
(41, 22, 'Divya Madushani', 'divya@gmail.com', '0761234567', 'I have been shopping at this cosmetic store for years, and I must say that the new management system has made the shopping experience even better!', 'cus1.jpg', 'NotApproved'),
(42, 20, 'Sanjana Jayaveera', 'sanju123@gmail.com', '0765449397', 'I recently placed an order online through the cosmetic store\'s website, and I was amazed by how smooth and efficient the entire process was.', 'cus2.jpg', 'Approve'),
(47, 24, 'Hannah', 'hannah@gmail.com', '0754444222', 'The face wash was well-packaged and seemed to work wonders. It doesn\'t leave my face feeling oily or stripped. Some face washes leave a weird residue behind but not this one!.', 'pic-5.jpg', 'Approve'),
(46, 24, 'Anne', 'anne@gmail.com', '0768882222', 'Great transaction and communication. Gorgeous moisturizer, that makes my dry skin feel soft and supple. Smells lovely too. Highly recommend it—many thanks as always.', 'pic-4.png', 'Approve'),
(45, 24, 'Nathalie', 'nathalia@gmail.com', '0748887777', 'I appreciate the seriousness and wholesomeness of this brand. I’m impressed by the high-quality ingredients, lovely natural scents from essential oils, and plastic-free packaging. Thank you!', 'pic-1.jpg', 'Approve'),
(44, 24, 'Jules Frances', 'jules@gmail.com', '0772221117', 'I’m very keen on these amazing products by Conscious Skincare. They not only smell divine, and feel gorgeous but have the ingredients that I dream of!', 'pic-2.png', 'Approve');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `delivery_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'processing',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`, `delivery_status`) VALUES
(31, 22, 'Divya Madushani', '0761234567', 'divya@gmail.com', 'cash on delivery', '256 A/2 Nittambuwa', ', Perfume (2) , Shampoo & Conditionor (2) , Night Cream (1) ', 32990, '01-Jul-2023', 'completed', 'delivered'),
(32, 22, 'Divya Madushani', '0761234567', 'divya@gmail.com', 'cash on delivery', '256 A/2 Nittambuwa', ', Face Cream (1) , Night Cream (1) , Mascara Dry (1) , Skin Toner (1) ', 24470, '01-Jul-2023', 'completed', 'delivering'),
(33, 20, 'Sanjana Jayaveera', '0765449397', 'sanju123@gmail.com', 'cash on delivery', 'Veyangoda', ', Body Lotion (1) , Perfume (2) ', 13000, '01-Jul-2023', 'pending', 'delivered'),
(34, 20, 'Sanjana Jayaveera', '0765449397', 'sanju123@gmail.com', 'cash on delivery', 'Veyangoda', ', Lipstick Light Rose (3) ', 21000, '01-Jul-2023', 'pending', 'processing'),
(35, 23, 'Ramya Wasanthi', '0761234567', 'ramya123@gmail.com', 'cash on delivery', 'Veyangoda', ', Lipstick Matte (2) ', 9000, '01-Jul-2023', 'completed', 'delivered'),
(36, 24, 'Amali Perera', '0761234567', 'amali@gmail.com', 'cash on delivery', 'Colombo 5', ', Mascara Matte (1) , Skin Toner (2) , Face Cream (1) , Night Cream (1) ', 28970, '02-Jul-2023', 'completed', 'delivered'),
(38, 24, 'Amali Perera', '0761234567', 'amali@gmail.com', 'cash on delivery', 'Colombo 5', ', Mascara Dry (1) , Skin Toner (1) ', 8490, '04-Jul-2023', 'pending', 'processing'),
(39, 25, 'kamal Perera', '0761234567', 'kamal@gmail.com', 'cash on delivery', '256 A/2 Nittambuwa', ', Mascara (1) , Lipstick Matte (1) , Perfume (2) ', 18000, '04-Jul-2023', 'completed', 'delivered');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(4, 'Perfume', 5000, 'Perfume - Oriflame.jpg'),
(8, 'Mascara Matte', 2990, 'Mascara - Lakme.jpg'),
(14, 'Face Cream', 6990, 'Face Cream - Oriflame.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(25, 'kamal Perera', 'kamal@gmail.com', 'b24331b1a138cde62aa1f679164fc62f', 'user'),
(26, 'kamal', 'kamal@gmail.com', '6f89cf12cd377f97fb70c0bd9734a165', 'user'),
(20, 'Sanjana Jayaveera', 'sanju123@gmail.com', 'b24331b1a138cde62aa1f679164fc62f', 'user'),
(21, 'Kalpana Madushani', 'mkalpana795@gmail.com', 'ea57cba023acfb3a54952f48bc9211b6', 'admin'),
(22, 'Divya Madushani', 'divya@gmail.com', '9d6c49d026bbb5de9b7b6e4faa208520', 'user'),
(23, 'Ramya Wasanthi', 'ramya123@gmail.com', '202cb962ac59075b964b07152d234b70', 'user'),
(24, 'Amali Perera', 'amali@gmail.com', 'c4b94fae3048aad09f3dfcd8bf4acd2d', 'user');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
