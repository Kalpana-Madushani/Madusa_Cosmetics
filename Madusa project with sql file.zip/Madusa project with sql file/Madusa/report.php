<?php

include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
};


if(isset($_POST['submit'])){

   echo '<script>window.open("sales.php", "_blank");</script>';
   

   $start_date = $_POST['from'];
   $end_date = $_POST['to'];

   $newstart_date = date("d-M-Y", strtotime($start_date));
   $newend_date = date("d-M-Y", strtotime($end_date));

   
   $newstart_date = mysqli_real_escape_string($conn, $newstart_date);
   $newend_date = mysqli_real_escape_string($conn, $newend_date);

   
   $_SESSION['d1'] = $newstart_date;
   $_SESSION['d2'] = $newend_date;

   
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Madusa:: Essence Of Beauty </title>
   <link rel="icon" href="favicon.ico">

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>



<section class="add-products">

   <h1 class="title">reports</h1>

   <form action="" method="post">
      <h3>select report</h3>

      <select name="name" class="box" required>

         <option value="sales">Sales Product</option>
         <option value="users">Users</option>
      </select>
      
      <input type="date" id="from" name="from" class="box" placeholder="From" required>
      <input type="date" id="to" name="to" class="box" placeholder="To" required>
      <input type="submit" value="Filter" id="filter" name="submit" class="btn">
        
   </form>
</section>

<script>
   if(window.history.replaceState){
      window.history.replaceState(null, null, window.location.href);
   }
</script>


<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>