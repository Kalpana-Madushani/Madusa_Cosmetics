<?php

include 'config.php';

session_start();


$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:admin_login.php');
};


$d1 = $_SESSION['d1'];
$d2 = $_SESSION['d2'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Madusa:: Essence Of Beauty </title>
    <link rel="icon" href="favicon.ico">

    <style>
        .table-container {
            display: flex;
            justify-content: center;
        }

        table {
            border-collapse: collapse;
            width: 90%;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
        }

        .print {
            background-color: #f39c12;
            margin-top: 1rem;
            margin-left: 43rem;
            padding: 1rem 1rem;
            cursor: pointer;
            font-size: 1rem;
            border-radius: .5rem;
            display: block;
        }

        @media print {
            .print {
                display: none;
            }
        }
    </style>

</head>

<body>
    <div class="table-container">

        <?php
        $query = "SELECT * FROM `orders` WHERE `placed_on` BETWEEN '$d1' AND '$d2' AND `payment_status` = 'completed'";
        $result = mysqli_query($conn, $query);
        if ($result === false) {
            echo "Query execution failed: " . mysqli_error($conn);
        } else {
            if (mysqli_num_rows($result) > 0) {
        ?>
                <table>
                    <caption>
                        <h2>Sales Product Report (<?php echo $d1; ?> to <?php echo $d2; ?> )</h2>
                    </caption>
                    <tr>
                        <th>Placed On</th>
                        <th>Name</th>
                        <th>Total Products</th>
                        <th>Total Price</th>
                    </tr>

            <?php
           
                while ($fetch_orders = mysqli_fetch_assoc($result)) {

                    echo "<tr>";
                    echo "<td>" . $fetch_orders['placed_on'] . "</td>";
                    echo "<td>" . $fetch_orders['name'] . "</td>";
                    echo "<td>" . $fetch_orders['total_products'] . "</td>";
                    echo "<td>Rs." . $fetch_orders['total_price'] . "/-</td>";
                    echo "</tr>";
                }
            } else {

                echo "<h1> No Sales Available ! </h1>";
            }
        }
        mysqli_close($conn);
            ?>
                </table>
    </div>

    <button class="print" onClick="window.print()">Print Report</button>

    <!-- custom admin js file link  -->
    <script src="js/admin_script.js"></script>

</body>

</html>