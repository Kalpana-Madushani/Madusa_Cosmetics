<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Madusa:: Essence Of Beauty </title>
   <link rel="icon" href="favicon.ico">

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>about us</h3>
   <p> <a href="home.php">home</a> / about </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about.jpg" alt="">
      </div>

      <div class="content">
         <h3>why choose us?</h3>
         <p>One is a small compassionate cosmetics company.
            Our first collection consists of face, eyes and lips, all of which are hard-working, 
            fabulously formulated and easy to apply.Our products won’t block your pores and are suitable for all skin types, 
            even sensitive skin! One make-up has a full, rich, velvety pigment. You’ll find it blends like a dream and stays put.</p>
         <p> </p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">client's reviews</h1>

   <div class="box-container">

      <?php  
         $select_message = mysqli_query($conn, "SELECT * FROM `message` WHERE status = 'Approve'") or die('query failed');
         if(mysqli_num_rows($select_message) > 0){
            while($fetch_message = mysqli_fetch_assoc($select_message)){
      ?>
      
      <div class="box">
         
         <img src="uploaded_img/<?php echo $fetch_message['image']; ?>" alt="">
         <p><?php echo $fetch_message['message']; ?></p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3><?php echo $fetch_message['name']; ?></h3>
      </div>
      
      <?php
        }
      
         }else{
            echo '<p class="empty">no messages added yet!</p>';
         }

      ?>

   </div>

</section>




<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>