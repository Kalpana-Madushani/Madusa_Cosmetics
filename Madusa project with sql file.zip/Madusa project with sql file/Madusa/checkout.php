<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['order_btn'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $number = $_POST['number'];
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $method = mysqli_real_escape_string($conn, $_POST['method']);
   $address = mysqli_real_escape_string($conn, $_POST['address']);
   $placed_on = date('d-M-Y');

   $cart_total = 0;
   $cart_products[] = '';

   $cart_query = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
   if(mysqli_num_rows($cart_query) > 0){
      while($cart_item = mysqli_fetch_assoc($cart_query)){
         $cart_products[] = $cart_item['name'].' ('.$cart_item['quantity'].') ';
         $sub_total = ($cart_item['price'] * $cart_item['quantity']);
         $cart_total += $sub_total;
      }
   }

   $total_products = implode(', ',$cart_products);

   $order_query = mysqli_query($conn, "SELECT * FROM `orders` WHERE name = '$name' AND number = '$number' AND email = '$email' AND method = '$method' AND address = '$address' AND total_products = '$total_products' AND total_price = '$cart_total'") or die('query failed');

   if($cart_total == 0){
      $message[] = 'your cart is empty!';
   }else{
      if(mysqli_num_rows($order_query) > 0){
         $message[] = 'order already placed!'; 
      }else{
         mysqli_query($conn, "INSERT INTO `orders`(user_id, name, number, email, method, address, total_products, total_price, placed_on) VALUES('$user_id', '$name', '$number', '$email', '$method', '$address', '$total_products', '$cart_total', '$placed_on')") or die('query failed');
         $message[] = 'order placed successfully!';
         mysqli_query($conn, "DELETE FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
      }
   }
   
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Madusa:: Essence Of Beauty </title>
   <link rel="icon" href="favicon.ico">
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>checkout</h3>
   <p> <a href="home.php">home</a> / checkout </p>
</div>

<section class="display-order">

   <?php  
      $grand_total = 0;
      $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select_cart) > 0){
         while($fetch_cart = mysqli_fetch_assoc($select_cart)){
            $total_price = ($fetch_cart['price'] * $fetch_cart['quantity']);
            $grand_total += $total_price;
   ?>
   <p> <?php echo $fetch_cart['name']; ?> <span>(<?php echo 'Rs.'.$fetch_cart['price'].'/-'.' x '. $fetch_cart['quantity']; ?>)</span> </p>
   <?php
      }
   }else{
      echo '<p class="empty">your cart is empty</p>';
   }
   ?>
   <div class="grand-total"> grand total : <span>Rs.<?php echo $grand_total; ?>/-</span> </div>

</section>

<section class="checkout">

      <?php
         $data_query = mysqli_query($conn, "SELECT * FROM `users` WHERE id = '$user_id'") or die('query failed');
         if(mysqli_num_rows($data_query) > 0){
            while($fetch_data = mysqli_fetch_assoc($data_query)){
      ?>

   <form action="" method="post">
      <h3>place your order</h3>
      <div class="flex">

         <div class="inputBox">
            <span>your name :</span>
            <input type="text" name="name" required placeholder="enter your name" value="<?php echo $fetch_data['name']; ?>">
         </div>

         <div class="inputBox">
            <span>your phone number :</span>
            <input type="text" max="10" name="number" id="number" required placeholder="enter your phone number" onblur="validatePhoneNumber(this)">
            <span id="phone-error" style="color: red;"></span>
         </div>

         <div class="inputBox">
            <span>your email :</span>
            <input type="email" name="email" required placeholder="enter your email" value="<?php echo $fetch_data['email']; ?>">
         </div>

         <div class="inputBox">
            <span>address :</span>
            <input type="text" min="0" name="address" required placeholder="enter your home address">
         </div>

         <div class="inputBox">
            <span>payment method :</span>
            <input type="text" name="method" value="cash on delivery">
         </div>
         
         <div class="inputBox">
            <span>postal code :</span>
            <input type="text" name="pin_code" required placeholder="e.g. 11111" onblur="validatePostalCode(this)">
            <span id="postal-error" style="color: red;"></span>
         </div>

      </div>
      <input type="submit" value="order now" class="btn" name="order_btn">
   </form>

   <?php
       }
      }
      ?>

</section>

<script>
function validatePhoneNumber(input) {
  var phoneNumber = input.value;
  var phoneError = document.getElementById('phone-error');
  
  // Perform client-side validation
  var regex = /^\d{10}$/; // Regular expression for 10-digit phone number format

  if (!regex.test(phoneNumber)) {
    phoneError.textContent = 'Please enter a valid 10-digit phone number.';
    input.style.borderColor = 'red';
  } else {
    phoneError.textContent = '';
    input.style.borderColor = ''; // Reset the border color
  }
}

function validatePostalCode(input) {
  var postalcode = input.value;
  var postalError = document.getElementById('postal-error');
  
  // Perform client-side validation
  var regex = /^\d{5}$/; // Regular expression for 5-digit postal code format

  if (!regex.test(postalcode)) {
   postalError.textContent = 'Please enter a valid 5-digit postal code.';
    input.style.borderColor = 'red';
  } else {
   postalError.textContent = '';
    input.style.borderColor = ''; // Reset the border color
  }
}
</script>


<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>