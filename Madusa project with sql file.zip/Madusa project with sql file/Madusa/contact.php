<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['send'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   
   $msg = mysqli_real_escape_string($conn, $_POST['message']);

   $cus_image = $_POST['cus_image'];
   


   $select_message = mysqli_query($conn, "SELECT * FROM `message` WHERE name = '$name' AND email = '$email' AND number = '$number' AND message = '$msg'") or die('query failed');

   if(mysqli_num_rows($select_message) > 0){
      $message[] = 'message sent already!';
   }else{
      $add_msg_query = mysqli_query($conn, "INSERT INTO `message`(user_id, name, email, number, message, image) VALUES('$user_id', '$name', '$email', '$number', '$msg', '$cus_image')") or die('query failed');
      $message[] = 'message sent successfully!';
   }
   

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Madusa:: Essence Of Beauty </title>
   <link rel="icon" href="favicon.ico">
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>contact us</h3>
   <p> <a href="home.php">home</a> / feedback </p>
</div>

<section class="contact">

      <?php
         $data_query = mysqli_query($conn, "SELECT * FROM `users` WHERE id = '$user_id'") or die('query failed');
         if(mysqli_num_rows($data_query) > 0){
            while($fetch_data = mysqli_fetch_assoc($data_query)){
      ?>

   <form action="" method="post">
      <h3>say something!</h3>
      <input type="text" name="name" required placeholder="enter your name" class="box" value="<?php echo $fetch_data['name']; ?>">
      <input type="email" name="email" required placeholder="enter your email" class="box" value="<?php echo $fetch_data['email']; ?>">

      <input type="text" name="number" required placeholder="enter your phone number" class="box" onblur="validatePhoneNumber(this)">
      <span id="phone-error" style="color: red;"></span>
      
      <input type="file" name="cus_image" accept="image/jpg, image/jpeg, image/png" class="box">
      <textarea name="message" class="box" placeholder="enter your message" id="" cols="30" rows="10"></textarea>
      <input type="submit" value="send message" name="send" class="btn">
   </form>

   <?php
       }
      }
      ?>

</section>


<script>
function validatePhoneNumber(input) {
  var phoneNumber = input.value;
  var phoneError = document.getElementById('phone-error');
  
  // Perform client-side validation
  var regex = /^\d{10}$/; // Regular expression for 10-digit phone number format

  if (!regex.test(phoneNumber)) {
    phoneError.textContent = 'Please enter a valid 10-digit phone number.';
    input.style.borderColor = 'red';
  } else {
    phoneError.textContent = '';
    input.style.borderColor = ''; // Reset the border color
  }
}
</script>





<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>